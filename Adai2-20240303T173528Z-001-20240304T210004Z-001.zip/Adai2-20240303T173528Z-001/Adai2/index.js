const toggle = document.querySelector(".toggle")
const navMenu = document.querySelector(".nav-menu")
toggle.addEventListener("click",()=>{
    navMenu.classList.toggle("nav-menvi");
});